<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="myproject_1";

$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully .'<br>' ";

$sql = "CREATE TABLE student_user(
u_id INT(11) AUTO_INCREMENT,
u_name VARCHAR(30),
college VARCHAR(30),
degree VARCHAR(5), 
specialization VARCHAR(5),
year_of_study VARCHAR(2),
city VARCHAR(15),
state VARCHAR(15),
contact_number VARCHAR(14),
email VARCHAR(30),
password VARCHAR(10),
PRIMARY KEY (u_id)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table student_user created successfully \n<br />";
} else {
    echo "not creating table: " . $conn->error.'<br />';
}

$name = mysqli_real_escape_string($conn, $_REQUEST['name']);
$college = mysqli_real_escape_string($conn, $_REQUEST['college']);
$degree = mysqli_real_escape_string($conn, $_REQUEST['degree']);
$specialization = mysqli_real_escape_string($conn, $_REQUEST['specialization']);
$year = mysqli_real_escape_string($conn, $_REQUEST['year']);
$city = mysqli_real_escape_string($conn, $_REQUEST['city']);
$state = mysqli_real_escape_string($conn, $_REQUEST['state']);
$num = mysqli_real_escape_string($conn, $_REQUEST['num']);
$email = mysqli_real_escape_string($conn, $_REQUEST['email']);
$password = mysqli_real_escape_string($conn, $_REQUEST['password']);
 
$sql_u = "SELECT * FROM student_user WHERE           u_name='$name'";
$sql_e = "SELECT * FROM student_user WHERE 	  email='$email'";
$res_u = mysqli_query($conn, $sql_u);
$res_e = mysqli_query($conn, $sql_e);

if ((mysqli_num_rows($res_u)) > 0) {
  	  echo "username already taken"; 	 
 }else if((mysqli_num_rows($res_e)) > 0){
  	 echo "email already taken"; 	
 }else{
$sql = "INSERT INTO student_user(u_name,college,degree,specialization,year_of_study,city,state,contact_number,email,password) VALUES ('$name', '$college', '$degree', '$specialization', '$year', '$city', '$state', '$num', '$email', '$password')";
if(mysqli_query($conn, $sql)){
    echo "Records added successfully. \n ";
} else{
    echo "error not able to execute $sql. " . mysqli_error($conn);
}
}
header("refresh:4; url='1.home.html'");
$conn->close();
?>