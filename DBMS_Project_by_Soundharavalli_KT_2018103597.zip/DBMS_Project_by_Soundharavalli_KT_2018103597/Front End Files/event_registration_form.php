<html>
<head>
<title>Event_Registration_Form</title>
<style>
	div{
			width:600px; 
			border:2px solid gray;
			margin:-5px;
			padding:20px;
		}
</style>
</head>
<body>
<center>
<br><br><br><br><br>
<div align="center">
<h1>Event_Registration_Form</h1>
</div>
<div>
<form align="center" action="regdetails.php" method="post">
Event Name : <input type="text" name="e_name" value="" required /><br><br><br>
Event Id : <input type="text" name="e_id" value="" required /><br><br><br>
User Id : <input type="text" name="u_id" value="" required /><br><br><br>
Name : <input type="text" name="u_name" value="" required /><br><br><br>
<input type="submit" value="Register" />
</form> 
</div>
<center
</body>
</html>
