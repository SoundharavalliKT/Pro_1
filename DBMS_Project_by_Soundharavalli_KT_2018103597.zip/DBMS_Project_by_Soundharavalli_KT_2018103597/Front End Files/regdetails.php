<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="myproject_1";

$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully.'<br />'";

$e_name = mysqli_real_escape_string($conn, $_REQUEST['e_name']);
$e_id = mysqli_real_escape_string($conn, $_REQUEST['e_id']);
$u_id = mysqli_real_escape_string($conn, $_REQUEST['u_id']);
$u_name = mysqli_real_escape_string($conn, $_REQUEST['u_name']);

$sql_e = "SELECT * FROM student_user WHERE  u_name='$u_name'";
$sql_p = "SELECT u_id FROM student_user WHERE          u_name='$u_name' AND u_id='$u_id'";
$res_p = mysqli_query($conn, $sql_p);
$res_e = mysqli_query($conn, $sql_e);

$sql_a = "SELECT * FROM event WHERE  e_name='$e_name'";
$sql_b = "SELECT e_id FROM event WHERE          e_name='$e_name' AND e_id='$e_id'";
$res_b = mysqli_query($conn, $sql_b);
$res_a = mysqli_query($conn, $sql_a);

if(mysqli_num_rows($res_e) <= 0) {
  	 echo "invalid User Name.'<br />'";
}
else if(mysqli_num_rows($res_p) <= 0){ 
	echo "invalid User Id.'<br />'";
}
else if(mysqli_num_rows($res_a) <= 0) {
  	 echo "invalid Event Name.'<br />'";
}
else if(mysqli_num_rows($res_b) <= 0){ 
	echo "invalid Event Id.'<br />'";
}
else{
	echo "Registration Successful.'<br />'";
	
$sql = "CREATE TABLE event_registration(
e_name VARCHAR(20),
e_id VARCHAR(6),
u_id INT(11),
u_name VARCHAR(30),
PRIMARY KEY(e_id,u_id),
FOREIGN KEY(e_id) REFERENCES event(e_id),
FOREIGN KEY(u_id) REFERENCES student_user(u_id)
)";


if ($conn->query($sql) == TRUE) {
    echo "Table student_user created successfully.'<br />'";
} else {
    echo "not creating table: " . $conn->error."<br />";
}


$query1=" SELECT * FROM event_registration WHERE e_id='$e_id' ";
$result1 = mysqli_query($conn,$query1);
$result2 = mysqli_num_rows($result1);

	$sql="INSERT INTO event_registration(e_name,e_id,u_id,u_name) VALUES ('$e_name' ,'$e_id' ,'$u_id' ,'$u_name')";
	if($result2<6){
		if(mysqli_query($conn, $sql)){
			echo " Records added successfully <br /> ";
		} 
		else{
			echo "<b> You had already registered for this event. </b></br >".$conn->error.'</br >' ;
		}
	}
	else{
		echo "<b> Seats are filled! Try for some other events. </b></br>";
	}
}

header("refresh:6; url='event_registration_form.php'");


$conn->close();
?>