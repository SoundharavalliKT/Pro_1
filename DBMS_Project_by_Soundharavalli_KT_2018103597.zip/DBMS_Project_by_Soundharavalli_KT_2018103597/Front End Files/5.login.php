<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="myproject_1";

$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";

$email = mysqli_real_escape_string($conn, $_REQUEST['email']);
$password = mysqli_real_escape_string($conn, $_REQUEST['password']);

$sql_e = "SELECT * FROM student_user WHERE  email='$email'";
$sql_p = "SELECT password FROM student_user WHERE           email='$email' AND password='$password'";
$res_p = mysqli_query($conn, $sql_p);
$res_e = mysqli_query($conn, $sql_e);

if(mysqli_num_rows($res_e) <= 0) {
  	 echo "invalid email";
}
else if(mysqli_num_rows($res_p) <= 0){ 
	echo "invalid password";
}
else{
	echo "login successful";
	header("Location: 6.welcome.php?email=".$_POST['email']."");
}

$conn->close();
?>