<!doctype html>
<html>
<head>
<title>STUDENT-USER</title>
<style>
	div{
			width:1290px; 
			border:2px solid gray;
			margin:-5px;
			padding:20px;
		}
	h3{
			width:400px; 
			border:2px solid gray;
			margin:-5px;
			padding:20px;
		}
</style>
</head>
<body> 

<div>
<h2>

STUDENT-USER Dashboard <br>

</div>
<div>
<h2>

<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myproject_1";



$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo " Connected successfully. '<br />' ";

$email = $_GET['email'];

$query = "SELECT * FROM student_user WHERE email='$email'";
echo "<b> Student Details </b> <br> <br>"; 
 
if ($result = $conn->query($query)) {
 
    while ($row = $result->fetch_assoc()) {
        $col1 = $row["u_id"];
        $col2 = $row["u_name"];
        $col3 = $row["college"];
        $col4 = $row["degree"];
        $col5 = $row["specialization"];
		$col6 = $row["year_of_study"];
		$col7 = $row["city"];
		$col8 = $row["state"];
		$col9 = $row["contact_number"];
		$col10 = $row["email"];
		$col11 = $row["password"];
		
        echo 'Id				:'.$col1.'<br />'; 
	 	echo 'Name				:'.$col2.'<br />';
        echo 'College			:'.$col3.'<br />';
        echo 'Degree			:'.$col4.'<br />';
        echo 'Branch			:'.$col5.'<br />';
		echo 'Year				:'.$col6.'<br />';
		echo 'City				:'.$col7.'<br />';
		echo 'State				:'.$col8.'<br />';
		echo 'Contact_Number	:'.$col9.'<br />';
		echo 'Email_Id			:'.$col10.'<br />';
		echo 'Password			:'.$col11.'<br />';
    }
 
 $result->free();
}

?>
</h2>
</div>
<div>
<h2>EVENT_REGISTRATION DETAILS:</h2><br /><br /><br />
<form action="event_registration_form.php" method="post">

<h3># Codestorm-202001</h3><br>
<h3># Hackathon-202001</h3><br>
<h3># Mindsweeper-202003</h3><br>
<h3># Interwizz-202004</h3><br>
<h3># Pytorque-202005</h3><br>
<h3># Deadlocked-202006</h3><br><br>
<input type="submit" value="Register"/>

</form>
</div>
<div>
<h2>WORKSHOP_REGISTRATION DETAILS:</h2><br /><br /><br />
<form action="ws_registration_form.php" method="post">

<h3># Sixth Sense Robotixs</h3><br>
<h3># Big Data Analysis</h3><br>
<h3># Internet of Things</h3><br>
<h3># Cloud Computing</h3><br>
<h3># Deep Learning</h3><br>
<h3># ML With Python</h3><br><br>
<input type="submit" value="Register"/>


</form>
</div>
<div align="right">
<form action="wel_e.php" method="post">
Enter Your User Id ::<input style="padding:5px" type="text" name="u_id" /><br><br>
<input type="submit" value="Click here to know your registered events and workshops !!" />
</form>
</div>
<div align="right">
<form action="10.feedback-form.html" method="post">
<input type="submit" value="Click here to give your feedback !!" />
</form>
</div>
<div><h1><pre>
  <button onclick="myFunction()">Contact us</button>	  <a href="https://www.gmail.com">email-supportfutura@gmail.com</a>     <a href="https://www.facebook.com/">fb-futura2k20</a>	 <a href="https://www.instagram.com/accounts/login/">inst-2k20@futura</a><br></pre></h1>
<footer align="right">Have a nice Coding Experience!!!</footer><br>
</div>
<script>
function myFunction() {
  alert("This is our Contact number '9835523316'");
}
</script>
</body>
</html>