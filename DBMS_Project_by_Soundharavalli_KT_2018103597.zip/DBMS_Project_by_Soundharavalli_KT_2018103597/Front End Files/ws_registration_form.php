<html>
<head>
<title>Event_Registration_Form</title>
<style>
	div{
			width:600px; 
			border:2px solid gray;
			margin:-5px;
			padding:20px;
		}
</style>
</head>
<body>
<center>
<br><br><br><br><br>
<div align="center">
<h1>Workshop_Registration_Form</h1>
</div>
<div>
<form align="center" action="ws_regdetails.php" method="post">
Workshop Name : <input type="text" name="w_name" required /><br><br><br>
Workshop Id : <input type="text" name="w_id" required /><br><br><br>
User Id : <input type="text" name="u_id" required /><br><br><br>
Name : <input type="text" name="u_name" required /><br><br><br>
<input type="submit" value="Register and Proceed with Payment" />
</form> 
</div>
<center
</body>
</html>
