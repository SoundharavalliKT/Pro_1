<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myproject_1";



$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo " Connected successfully <br />' ";

$u_id = mysqli_real_escape_string($conn, $_REQUEST['u_id']);

$query1 = "SELECT * FROM event_registration WHERE u_id='$u_id'";
$res1 = mysqli_query($conn,$query1);
echo "<b> <h1>Registered Events-Details</h1></b> <br> <br>"; 
$i = 1;
while($row1 = mysqli_fetch_array($res1)){
	
	$col1 = $row1['e_id'];
	$query2 = "SELECT * FROM event WHERE e_id='$col1'";
 
	if ($res2 = $conn->query($query2)) {
	
		while($row = $res2->fetch_assoc()){ 
			$col2 = $row["e_name"];
			$col3 = $row["e_type"];
			$col4 = $row["e_desc"];
			$col5 = $row["location"];
			$col6 = $row["department"];
			$col7 = $row["star_time"];
			$col8 = $row["end_time"];
		
			echo '<h2>Event - '.$i.'<br />';
			echo 'Event Name				:'.$col2.'<br />';
			echo 'Event Type				:'.$col3.'<br />';
			echo 'Event Description			:'.$col4.'<br />';
			echo 'Location					:'.$col5.'<br />';
			echo 'Department				:'.$col6.'<br />';
			echo 'Starting Time				:'.$col7.'<br />';
			echo 'Ending Time 				:'.$col8.'<br /></h2>';
		}
 
		$res2->free();
	}
	$i = $i+1;
}

$query2 = "SELECT * FROM workshop_registration WHERE u_id='$u_id'";
$res2 = mysqli_query($conn,$query2);
echo "<b> <h1>Registered Workshop-Details</h1></b> <br> <br>"; 
$i = 1;
while($row2 = mysqli_fetch_array($res2)){
	
	$col2 = $row2['w_id'];
	$query2 = "SELECT * FROM workshop WHERE w_id='$col2'";
 
	if ($res3 = $conn->query($query2)) {
	
		while($row = $res3->fetch_assoc()){ 
			$col2 = $row["w_name"];
			$col3 = $row["w_id"];
			$col4 = $row["amount"];
		
			echo '<h2>Workshop - '.$i.'<br />';
			echo 'Workshop Name				:'.$col2.'<br />';
			echo 'Workshop ID				:'.$col3.'<br />';
			echo 'Amount					:'.$col4.'<br />';
			
		}
 
		$res3->free();
	}
	$i = $i+1;
}
?>