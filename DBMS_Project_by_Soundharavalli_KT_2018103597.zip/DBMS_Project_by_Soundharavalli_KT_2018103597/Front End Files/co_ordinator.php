<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myproject_1";



$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo " <h2>Connected successfully</h2>";

$event_id = $_POST['event_id'];
$ws_id = $_POST['ws_id'];

$query1 = "SELECT * FROM event WHERE e_id='$event_id'";
$res = mysqli_query($conn,$query1);
$query2 = "SELECT u_id FROM event_registration WHERE e_id='$event_id'";
$result2_u = mysqli_query($conn,$query2);
$result2 = mysqli_num_rows($result2_u);
$a = "SELECT c_name FROM co_ordinator WHERE e_id='$event_id'";
$b = mysqli_query($conn,$a);

if(mysqli_num_rows($res) <=0 ){
		echo "<h5>Not a Proper Event Id entered</h5><br><br>";
}else{

	echo " <h1>Event Details </h1>";  
	if ($result1 = $conn->query($query1)) {
 
    while ($row = $result1->fetch_assoc()) {
        $col1 = $row["e_id"];
        $col2 = $row["e_name"];
        $col3 = $row["location"];
        $col4 = $row["department"];
        $col5 = $row["start_time"];
		$col6 = $row["end_time"];
		$col7 = $row["e_desc"];

		
        echo '<h2>Event_name				:'.$col1.'<br />'; 
	 	echo 'Event_id				:'.$col2.'<br />';
        echo 'Location			:'.$col3.'<br />';
        echo 'Deparment			:'.$col4.'<br />';
        echo 'Start_time			:'.$col5.'<br />';
		echo 'End_time			:'.$col6.'<br />';
		echo 'Event_Desc				:'.$col7.'<br /><br />';
		echo 'Event_Co_ordinator Name  :';
			while($row = $b->fetch_assoc()) {
				echo $row['c_name'].'</h2>'; 
			}
	}
 
	$result1->free();
}

	echo "<h2>Number of students Registered for this event so far :<br>" ;
	echo "Count= ".$result2.'<br>';
}


$query3 = "SELECT * FROM workshop WHERE w_id='$ws_id'";
$ress = mysqli_query($conn,$query3);
$query4 = "SELECT u_id FROM workshop_registration WHERE w_id='$ws_id'";
$ressult2_u = mysqli_query($conn,$query4);
$ressult2 = mysqli_num_rows($ressult2_u);
$i = "SELECT c_name FROM co_ordinator WHERE w_id='$ws_id'";
$j = mysqli_query($conn,$i);

if(mysqli_num_rows($ress) <=0 ){
		echo "<br><br><h5>Not a proper Workshop Id entered</h5>";
}else{

	echo " <h1>Workshop Details </h1>";  
	if ($ressult1 = $conn->query($query3)) {
 
    while ($row = $ressult1->fetch_assoc()) {
        $col1 = $row["w_id"];
        $col2 = $row["w_name"];
        $col3 = $row["amount"];

		
        echo '<h2>Workshop_name				:'.$col1.'<br />'; 
	 	echo 'Workshop_id				:'.$col2.'<br />';
        echo 'Amount			:'.$col3.'<br />';
		echo 'Workshop_Co_ordinator Name  :';
			while($row = $j->fetch_assoc()) {
				echo $row['c_name'].'</h2>'; 
			}
	}
 
	$ressult1->free();
}

	echo "<h2>Number of students Registered for this workshop so far :<br>" ;
	echo "Count= ".$ressult2.'<br>';
}
?>