<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="myproject_1";

$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully \n <br />";

$sql = "CREATE TABLE feedback(
f_id INT(11) AUTO_INCREMENT,
u_id INT(11),
e_id VARCHAR(6),
feedback VARCHAR(20),
compliments VARCHAR(50),
PRIMARY KEY (f_id),
FOREIGN KEY(u_id) REFERENCES student_user(u_id),
FOREIGN KEY(e_id) REFERENCES event(e_id)
)";

if ($conn->query($sql) == TRUE) {
    echo "Table feedback created successfully \n <br />";
} else {
    echo "not creating table: <br /> " . $conn->error. '<br />';
}
 
$u_id = mysqli_real_escape_string($conn, $_REQUEST['u_id']);
$e_id = mysqli_real_escape_string($conn, $_REQUEST['e_id']);
$feedback = mysqli_real_escape_string($conn, $_REQUEST['feedback']);
$suggestion = mysqli_real_escape_string($conn, $_REQUEST['suggestion']);


$sql = "INSERT INTO feedback(u_id,e_id,feedback,compliments) VALUES ('$u_id','$e_id','$feedback','$suggestion')";
if(mysqli_query($conn, $sql)){
    echo "Records added successfully. \n <br />";
} else{
    echo "error not able to execute $sql. " . mysqli_error($conn);
} 

header("refresh:5; url='1.home.html'"); 
$conn->close();
?>