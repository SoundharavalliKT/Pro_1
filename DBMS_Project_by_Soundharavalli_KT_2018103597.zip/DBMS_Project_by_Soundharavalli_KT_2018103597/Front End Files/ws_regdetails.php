<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="myproject_1";

$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully.'<br />'";

$w_name = mysqli_real_escape_string($conn, $_REQUEST['w_name']);
$w_id = mysqli_real_escape_string($conn, $_REQUEST['w_id']);
$u_id = mysqli_real_escape_string($conn, $_REQUEST['u_id']);
$u_name = mysqli_real_escape_string($conn, $_REQUEST['u_name']);

$sql_e = "SELECT * FROM student_user WHERE  u_name='$u_name'";
$sql_p = "SELECT u_id FROM student_user WHERE          u_name='$u_name' AND u_id='$u_id'";
$res_p = mysqli_query($conn, $sql_p);
$res_e = mysqli_query($conn, $sql_e);

$sql_a = "SELECT * FROM workshop WHERE  w_name='$w_name'";
$sql_b = "SELECT w_id FROM workshop WHERE          w_name='$w_name' AND w_id='$w_id'";
$res_b = mysqli_query($conn, $sql_b);
$res_a = mysqli_query($conn, $sql_a);

if(mysqli_num_rows($res_e) <= 0) { 
  	 echo "invalid User Name.'<br />'";
}
else if(mysqli_num_rows($res_p) <= 0){ 
	echo "invalid User Id.'<br />'";
}
else if(mysqli_num_rows($res_a) <= 0) {
  	 echo "invalid Workshop Name.'<br />'";
}
else if(mysqli_num_rows($res_b) <= 0){ 
	echo "invalid Workshop Id.'<br />'";
}
else{
	echo "Registration Successful.'<br />'";
	
$sql = "CREATE TABLE workshop_registration(
w_name VARCHAR(20),
w_id VARCHAR(10),
u_id INT(11),
u_name VARCHAR(30),
PRIMARY KEY(w_id,u_id),
FOREIGN KEY(w_id) REFERENCES workshop(w_id),
FOREIGN KEY(u_id) REFERENCES student_user(u_id)
)";

if ($conn->query($sql) == TRUE) {
    echo "Table student_user created successfully.'<br />'";
} else {
    echo "not creating table: " . $conn->error."<br />";
}

$query1=" SELECT * FROM workshop_registration WHERE w_id='$w_id' ";
$result1 = mysqli_query($conn,$query1);
$result2 = mysqli_num_rows($result1);

	$sql="INSERT INTO workshop_registration(w_name,w_id,u_id,u_name) VALUES ('$w_name' ,'$w_id' ,'$u_id' ,'$u_name')";
	if($result2<10){
		if(mysqli_query($conn, $sql)){
			echo " Records added successfully <br /> ";
			header("refresh:4; url='https://pay.google.com/'");
		} 
		else{
			echo "<b> You had already registered for this workshop. </b></br >".$conn->error.'</br >' ;
		}
	}
	else{
		echo "<b> Seats are filled! Try for some other events. </b></br>";
	}


/*$sql = "INSERT INTO workshop_registration(w_name,w_id,u_id,u_name) VALUES ('$w_name' ,'$w_id' ,'$u_id' ,'$u_name')";
if(mysqli_query($conn, $sql)){
    echo "Records added successfully.'<br />'. \n ";
	header("refresh:4; url='https://pay.google.com/'");

} else{
    echo "<b>Error not able to register.Since,You had already registered for this workshop.</b> <br /> Error:" . mysqli_error($conn);
}*/


}


$conn->close();
?>